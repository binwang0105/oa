import static org.junit.Assert.*;
import org.junit.*;

public class Q1Test{

    Solution1 s;
    Node new_nullnode;
    Node new_singlenode;
    Node newhead;
	
	@Before
	public void before() {
         s = new Solution1();
            
         //null
         Node nullnode = null;
         new_nullnode = s.reverse(nullnode);
      
         //single node
         Node singlenode = new Node(2);
         new_singlenode = s.reverse(singlenode);
      
         //multiple nodes
         Node node1 = new Node(3);
	     Node node2 = new Node(4);
	     Node node3 = new Node(5);
	     node1.next = node2;
         node2.next = node3;
	     node3.next = null;
         newhead = s.reverse(node1);
	}
	
	@Test
	public void testNull(){
	    assertEquals(true, new_nullnode == null);
	}
	
	@Test
	public void testSingle(){
	    assertEquals(true, new_singlenode.value == 2);
	}
  
  	@Test
	public void testMultiple(){
      	    Node cur = newhead;
            int v = 5;
      	    while(cur != null){
               int val = cur.value;
	       assertEquals(true, v == val);
               v--;
	       cur = cur.next;
	    }
	}
	
	@After
	public void clean(){
            s = null;
    	    Node new_nullnode = null;
    	    Node new_singlenode = null;
    	    Node newhead = null;
	}
}