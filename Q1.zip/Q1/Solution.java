public class Solution {
	  public Node reverse(Node head){
	    if(head == null || head.next == null){
	    	return head;
	    }
	    
	    Node prev = null;
	    Node cur = head;
	    
	    while(cur != null){
	    	Node temp = cur.next;
	        cur.next = prev;
	        prev = cur;
	        cur = temp;
	    }
	    
	    return prev;
	  }
}

// Your resolution��We change the current node's next pointer to point to its previous element while traversing. 
// Time complexity:  O(n)
// Space complexity: O(1)
