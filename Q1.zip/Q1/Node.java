public class Node
{
    int value;
    Node next;
  	
    public Node(int val){
  	this.next = next;
    	this.value = val;
    }
}
