
public class Singleton {
	private volatile static Singleton s = null;
	private Singleton(){
		
	}
	
	public static Singleton getInstance(){
		if(s == null){	
			synchronized(Singleton.class){
				if(s == null){
					return new Singleton();
				}
			}
		}
		return s;
	}
}
