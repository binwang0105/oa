public class MultiDimensionArray {
    // This is a provided function, Assume it works
    public static Long getValue(int... indexOfDimension) {
        //... 
        return value;
    }

    // lengthOfDeminsion: each dimension's length, assume it is valid: lengthOfDeminsion[i]>0.
    public static Long sum(MultiDimensionArray mArray, int[] lengthOfDeminsion) { 
    //Confusing about the interfaces given, if possible please give more information and examples to help your candidates understand how to use these APIs.
    	Long res = (Long)0;
	if(lengthOfDeminsion[0] == 1){
		return getValue(mArray, 0);
	} else {
		for(int i = 0; i < lengthOfDeminsion[0]; i++){
			res += getValue(mArray, i);	
		}
	}
	return res;
    }
   // Resolution: Pretty lost in this question. I think I need more information and examples to understand it.
      Like the MultiDimensionArray above, is it a List? Or an Integer? If so, what kind of APIs 
      I can use and how to use them correctly? If my understanding is right, the input is a nested list? 
      If so, I think it is natural to think about the problem in a recursive way. To do it, we just go 
      through the list of nested integers one by one and that's it. To avoid recursion we can use Stack 
      to mock this process. But it's pretty interesting that no extra space allowed in this question. 
      I think you might want me to use getValue() to evade recursion but I truly don't know how to use it 
      correctly. I need more examples to show how to use this function. In my approach given above, I assume that 
      getValue(idx) will return the value(sum) of the nested integer at idx. So I just traverse the array and sum them up. 
   // Time complexity:  O(N), N represents the size of lengthOfDeminsion[0]
   // Space complexity: O(1)
}