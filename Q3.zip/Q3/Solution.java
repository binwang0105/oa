import java.util.List;

public class Solution {

	public boolean separate(List<Integer> list, int k){
	    // If k is 1, then always true
		if(k == 1){
			return true;
		}
		
		// k partition is impossible
		if(list.size() < k){
			return false;
		}
		
		int sum = 0;
		for(int i = 0; i < list.size(); i++){
			sum += list.get(i);
		}
		
		// if sum is not divisible, k partition is impossible
		double target = (double)sum/k;
		if(target != (int)target){
			return false;
		}
		
		// use backtrack try to find a solution. If found return true, else false
		return subSum(list, (int)target, k);
	}
	
	public boolean subSum(List<Integer> candidates, int target, int k) {
        int size = candidates.size();
		boolean[] helper = new boolean[size]; 
		// need to find k subsets with sum 'target' in the candidates given, so we execute k times
		for(int i = 0; i < k; i++){
			if(!dfs(helper, candidates, target, 0, k)){
				return false;
			}
		}
        return true;
    }
    
	//backtrack, if we find a subset, return true
    public boolean dfs(boolean[] helper, List<Integer> candidates, int target, int pos, int k){
        if(target == 0){
            return true;
        }
        if(target < 0){
            return false;
        }
        boolean res = false;
        //if we use a number, mark it used
        for(int i = pos; i < candidates.size(); i++){
        	if(helper[i] == false) {
	            helper[i] = true;
	            if(dfs(helper, candidates, target-candidates.get(i), i+1, k)){
	            	return true;
	            } else {
	            	helper[i] = false;
	            }
        	}
        }
        return res;
    }
// Your resolution: Please see my comments, thanks.
// Time complexity:  O(k * 2^n)  n is the size of the list
// Space complexity: O(n)
}
