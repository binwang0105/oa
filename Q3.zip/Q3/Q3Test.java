
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class Q3Test {

	Solution s;
	List<Integer> list;
	
	@Before
	public void init() {
		s = new Solution();
		list = new ArrayList<Integer>();
	}
	
	//input: k=1, list.size = 0
	//expected: true
	@Test
	public void test1(){
		assertEquals(true, s.separate(list, 1));
	}
	
	//input: k=1, list.size != 0
	//expected: true
	@Test
	public void test2(){
		list.add(1);
		assertEquals(true, s.separate(list, 1));
	}
	
	//input: k=2, list.size < k
	//expected: false
	@Test
	public void test3(){
		list.add(1);
		assertEquals(false, s.separate(list, 2));
	}
	
	//input: k=2, list.size < k
	//expected: false
	@Test
	public void test4(){
		list.add(1);
		assertEquals(false, s.separate(list, 2));
	}
	
	//comment: sum is not divisible by k
	//input: k=2, ele1 = 1, ele2 = 2, target = 1.5
    //expected: false
	@Test
	public void test5(){
		list.add(1);
		list.add(2);
		assertEquals(false, s.separate(list, 2));
	}
	
	//comment: target is smaller than some integers in the given list
	//input: k=2, ele1 = 3, ele2 = 5, target = 4
	//expected: false
	@Test
	public void test6(){
		list.add(3);
		list.add(5);
		assertEquals(false, s.separate(list, 2));
	}
	
	//comment: regular input(all elements are same) with target = sum/K
    //input: k=3, ele1 = 1, ele2 = 1, ele3 = 1, target = 1
	//expected: false
	@Test
	public void test7(){
		list.add(1);
		list.add(1);
		list.add(1);
		assertEquals(true, s.separate(list, 3));
	}
	
	//comment: regular input with target = sum/K
    //input: k=2, ele1 = 1, ele2 = 2, ele3 = 3, target = 3
	//expected: true
	@Test
	public void test8(){
		list.add(1);
		list.add(2);
		list.add(3);
		assertEquals(true, s.separate(list, 2));
	}
	
	//comment: regular input with target != sum/K
    //input: k=3, ele1 = 1, ele2 = 2, ele3 = 3, target = 2
	//expected: false
	@Test
	public void test9(){
		list.add(1);
		list.add(2);
		list.add(3);
		assertEquals(false, s.separate(list, 3));
	}
	
	@After
	public void clean(){
		list = null;
	}
}
